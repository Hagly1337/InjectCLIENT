#include <list>
#include <vector>
#include <string.h>
#include <pthread.h>
#include <thread>
#include <cstring>
#include <jni.h>
#include <unistd.h>
#include <fstream>
#include <iostream>
#include <dlfcn.h>
#include "Includes/Logger.h"
#include "Includes/obfuscate.h"
#include "Includes/charObfuscate.h"
#include "Includes/xorstr.hpp"
#include "Includes/Utils.h"
#include "Color.h"
#include <deque>
#include "Unity/Vector3.h"
#include "Unity/Quaternion.h"
#include "Unity/Vector2.h"
#include "Unity/Rect.h"
#include <dirent.h>
#include "JSON/JSON.h"
#include "ImGui/backends/imgui_impl_opengl3.h"
#include "KittyMemory/MemoryPatch.h"
#include "ImGui/backends/imgui_impl_android.h"
//#include "backends/imgui_impl_opengl3.h"
#define targetLibName ("libil2cpp.so")
#include "ByNameModding/BNM.hpp"
#include <stdio.h>
#include <time.h>
#include <EGL/egl.h>
#include <GLES2/gl2.h>
#include "imgui.h"
#include "imgui_internal.h"
#include <stdio.h>
#include "stddef.h"
#include <jni.h>
#include <curl/curl.h>
#include <openssl/rsa.h>
#include <openssl/pem.h>
#include <sys/system_properties.h>
using namespace std;
#include "Unity/Vector4.h"
using namespace BNM;
int glHeight, glWidth;
bool setup;
uintptr_t address;
#include "Includes/Dobby/dobby.h"
#include "Includes/Macros.h"
#include <EGL/egl.h>
#include <GLES2/gl2.h>
#include "imgui.h"
#include "imgui_internal.h"
#include "backends/imgui_impl_opengl3.h"
#include "../ImGui/imgui_internal.h"
#include "MenuCustoms.h"
#include "Verdana.h"
#include "Requests.h"
#include "autoaddr.h"
#include "Monostring.h"

#include "il2cpp-class.h"
#include "Xhook/xhook.h"
#include "Zygisk/zygisk.h"

using zygisk::Api;
using zygisk::AppSpecializeArgs;
using zygisk::ServerSpecializeArgs;

void hack();

bool russiaflagbool = true;

ulong il2cpp_base = 0;
ulong getLib(const char *lib, std::string perm) {
    std::string line;
    std::ifstream maps("/proc/self/maps");
    while (std::getline(maps, line)) {
        std::istringstream iss(line);
        std::string address, permissions, offset, zalupa, zalupa2, pathname;
        if (iss >> address >> permissions >> offset >> zalupa >> zalupa2 >> pathname &&
            pathname.find(lib) != std::string::npos && permissions == perm) {
            ulong start_address;
            std::istringstream(address.substr(0, address.find('-'))) >> std::hex >> start_address;
            return start_address;
        }
    }
    return 0;
}

#include <map>
template<typename TKey, typename TValue>
struct monoDictionary {
    struct Entry {
        [[maybe_unused]] int hashCode, next;
        TKey key;
        TValue value;
    };
    void *klass;
    void *monitor;
    [[maybe_unused]] monoArray<int> *buckets;
    monoArray<Entry> *entries;
    int count;
    int version;
    [[maybe_unused]] int freeList;
    [[maybe_unused]] int freeCount;
    void *compare;
    monoArray<TKey> *keys;
    monoArray<TValue> *values;
    [[maybe_unused]] void *syncRoot;
    std::vector<TKey> getKeys() {
        std::vector<TKey> ret;
        auto lst = entries->toCPPlist();
        for (auto enter : lst)
            ret.push_back(enter.key);
        return std::move(ret);
    }
    std::vector<TValue> getValues() {
        std::vector<TValue> ret;
        auto lst = entries->toCPPlist();
        for (auto enter : lst)
            ret.push_back(enter.value);
        return std::move(ret);
    }
    std::map<TKey, TValue> toMap() {
        std::map<TKey, TValue> ret;
        for (auto it = (Entry*)&entries->m_Items; it != ((Entry*)&entries->m_Items + count); ++it) ret.emplace(std::make_pair(it->key, it->value));
        return std::move(ret);
    }
    int getSize() { return count; }
    [[maybe_unused]] int getVersion() { return version; }
    bool TryGet(TKey key, TValue &value) { }
    [[maybe_unused]] void Add(TKey key, TValue value) { }
    [[maybe_unused]] void Insert(TKey key, TValue value) { }
    [[maybe_unused]] bool Remove(TKey key) { }
    [[maybe_unused]] bool ContainsKeyString(const char* key_to_find) {
        auto valuesVector = getValues();
        for (int j = 0; j > valuesVector.size(); ++j) {
            if (!strcmp(valuesVector[j]->c_str(), key_to_find)) {
                return true;
            }
        }
        return false;
    }
    [[maybe_unused]] bool ContainsValue(TValue value) { }
    TValue Get(TKey key) {
        TValue ret;
        if (TryGet(key, ret))
            return ret;
        return {};
    }
    TValue operator [](TKey key)  { return Get(key); }
};

static int knrn = 0;
const char *kn[] = { OBFUSCATE("M9 Bayonet Dragon Glass"),  OBFUSCATE("M9 Bayonet Scratch"), OBFUSCATE("M9 Bayonet Universe"), OBFUSCATE("M9 Bayonet Blue Blood"), OBFUSCATE("M9 Bayonet Digital Burst"), OBFUSCATE("M9 Bayonet Kumo"), OBFUSCATE("M9 Bayonet Frozen"), OBFUSCATE("M9 Bayonet Ancient"), OBFUSCATE("Butterfly Black Window"), OBFUSCATE("Sting Shroud"), OBFUSCATE("Karambit Pelagia"), OBFUSCATE("Sting Pelagia"), OBFUSCATE("Scorpion AHAU"), OBFUSCATE("Dual Daggers Tiki") };
static int glvn = 0;
const char *gl[] = { OBFUSCATE("Acid Veil"), OBFUSCATE("Plague") };

    void *(*il2cpp_class_from_name)(void *, const char *, const char *);
	void *(*il2cpp_assembly_get_image)(void *);
	void *(*il2cpp_class_get_field_from_name)(void *, const char *);
	void *(*il2cpp_domain_get)();
	void *(*il2cpp_domain_assembly_open)(void *, const char *);
	void *(*il2cpp_field_static_get_value)(void *, void *);

	
void *(*get_camera)();
void *(*get_transform)(void *);
void *(*get_bipedmap)(void *);
Vector3 (*WTS)(void *, Vector3);
int (*GetHealth)(void *i);
int (*GetTeam)(void *i);
int (*GetMoney)(void*i);
int (*GetArmor)(void*i);
int (*GetPlayerMoney)(void *photonplayer);
monoString*(*GetPlayerName)(void*);
Vector3 (*get_position)(void *);
bool (*GameManager$$Game)();
void*(*MainController_Instance)();


	namespace esp{
	namespace player {
		bool draw;
		bool box;
		bool fill;
		bool fooots;
		bool health;
		bool name;
		bool dist;
		bool armor;
		bool line;
		const char* hptype[] = {"Default","Gradient"};
		const char* armortypes[] = {"Default","Gradient"};
		int healthtype;
		int armortype;
		int linetype = 1;
		bool skeleton;
		bool money;
		float glow;
		bool weapon;
	}
	namespace weapon{
		bool enable;
	}
}

namespace colors {
	namespace esp {
		namespace grenade {
			float circlecolor[] = {0,0,0,1};
			float linecolor[] = {1,1,1,1};
		}
		namespace player {
			float HpColor[] = {1,1,1};
			float boxColor[] = {1,1,1};
			float fill_value = 150;
			float armorColor[] = {1,1,1};
			float skeletonColor[] = {1,1,1};
		}
	}
}
float hpcolor1[] = { 1,0,0 };
float hpcolor2[] = { 1,0,0 };
float armorcolor1[] = { 1,0,0 };
float armorcolor2[] = { 1,0,0 };

ImVec4  MoneyColor = { 0,1,0,1 };
ImVec4  BoxColor = { 1, 1, 1, 1 };
ImVec4  LineColor = { 1, 1, 1, 1 };

int cornedbox;
const char *TypesLine[] = {"Top", "Through"};


static void *lazySingletonField;
static void *lazySingleton;

static void *SingletonField;
static void *Singleton;


struct monoList 
{
 void*info;void*info2;void*info3;
 int size;
 void *ptr[0];
};
	
	static void *get_photon(void *player) 
	{
		return *(void **) ((uint64_t) player + 0x130);
	}
	
	View = player + 0xA8
    get_bipedmap = View + 0x58
	
	//monoDictionary<int, void*>* players;
	
	monoDictionary<int, void*>* player;
    monoDictionary<int, void*>* skins;
    void *playerc;

ImFont* verdana;
ImFont* pixel;
ImFont* smallpixel;
ImFont* tabs;
ImFont* fivepixel;
ImFont*SkeetNormal;
ImFont*SkeetSmall;

bool setskin;

static void* MainController_GetInvController()
{
 return *(void **)((uintptr_t)MainController_Instance() + string2Offset(OBFUSCATE("0xA0")));
}
static void* InventoryController_GetInvTabController()
{
 return *(void **)((uintptr_t)MainController_GetInvController() + string2Offset(OBFUSCATE("0x78")));
}
static void* InventoryTabController_GetPopupMenu()
{
 return *(void **)((uintptr_t)InventoryController_GetInvTabController() + string2Offset(OBFUSCATE("0x80")));
}
bool ChangeSkin(int newid = 71004) {
 void* BoltInventoryItem = *(void **)((uintptr_t)InventoryTabController_GetPopupMenu() + string2Offset(OBFUSCATE("0xA0")));
 if(BoltInventoryItem) {
  *(int *)((uintptr_t)BoltInventoryItem + string2Offset(OBFUSCATE("0x14"))) = newid;
  *(void **)((uintptr_t)InventoryTabController_GetPopupMenu() + string2Offset(OBFUSCATE("0xA0"))) = BoltInventoryItem;
  return true;
 }
 return false;
 }
 
 bool viewmodel;
 
 float X, Y, Z;
	  
	  void views() {
		  if (viewmodel) {
			  il2cpp_field_static_get_value((FieldInfo*) lazySingletonField, &lazySingleton);
				playerc = *(void **) ((uint64_t) lazySingleton + string2Offset(OBFUSCATE("0x80")));
				if (playerc) {
					auto arms = *(void **) ((uint64_t) playerc + string2Offset(OBFUSCATE("0x80")));
					if (arms != NULL) {
						if (viewmodel) {
							*(Vector3 *) ((uint64_t) arms + 0xf0) =
                            Vector3(X, Y, Z) / 50;
						}
					}
					    }
				   }
				   }
				   
bool boolllll;
float dpiscale = 1.5f;

float scale = 1.7f;

std::map<void*, bool>visiblechecker;

void DrawFilledCircleGlow(ImVec2 start, float radius, ImVec4 col, int segments, int gsize) {
    for (int i = 0; i < gsize; i++) {
        ImGui::GetWindowDrawList()->AddCircleFilled(start, radius + i, ImGui::GetColorU32(ImVec4(col.x, col.y, col.z, col.w * (1.0f * scale / (float)gsize) * (((float)(gsize - i)) / (float)gsize))), segments);
    }
}

void DrawMainText(ImVec2 CurrentWindowPos, const char* text) {
    ImGui::GetWindowDrawList()->AddText(ImVec2(185 * scale + CurrentWindowPos.x, 20 * scale + CurrentWindowPos.y), ImColor(255, 255, 255), text);
}

void DrawText(const char* text, ImVec2 pos, ImVec2 rel, ImColor color, bool outline, float size = 12) {
    float relx;
    float rely;
    switch ((int)rel.x) {
        case 0:
            relx = (ImGui::CalcTextSize(text).x / (22 * dpiscale) * (size * dpiscale)) / 2;
            break;
        case 1:
            relx = 0;
            break;
        case -1:
            relx = (ImGui::CalcTextSize(text).x / (22 * dpiscale) * (size * dpiscale));
            break;
    }
    switch ((int)rel.y) {
        case 0:
            rely = (ImGui::CalcTextSize(text).y / (22 * dpiscale) * (size * dpiscale)) / 2;
            break;
        case 1:
            rely = 0;
            break;
        case -1:
            rely = (ImGui::CalcTextSize(text).y / (22 * dpiscale) * (size * dpiscale));
            break;
    }
    if (outline) {
        ImGui::GetBackgroundDrawList()->AddText(pixel, size * dpiscale, ImVec2(pos.x - relx - 1, pos.y - rely - 1), ImColor(0, 0, 0), text);
        ImGui::GetBackgroundDrawList()->AddText(pixel, size * dpiscale, ImVec2(pos.x - relx + 1, pos.y - rely - 1), ImColor(0, 0, 0), text);
        ImGui::GetBackgroundDrawList()->AddText(pixel, size * dpiscale, ImVec2(pos.x - relx - 1, pos.y - rely + 1), ImColor(0, 0, 0), text);
        ImGui::GetBackgroundDrawList()->AddText(pixel, size * dpiscale, ImVec2(pos.x - relx + 1, pos.y - rely + 1), ImColor(0, 0, 0), text);
    }
    ImGui::GetBackgroundDrawList()->AddText(pixel, size * dpiscale, ImVec2(pos.x - relx, pos.y - rely), color, text);
	 //ImGui::GetBackgroundDrawList()->AddText(smallpixel, size * dpiscale, ImVec2(pos.x - relx, pos.y - rely), color, text);

}

ImVec2 world2screen_c(Vector3 pos, bool &checker) {
    auto cam = get_camera();
    if (!cam) return {0,0};

    Vector3 worldPoint = WTS(cam,pos);

    checker = worldPoint.z > 1;
    return ImVec2(worldPoint.x,glHeight - worldPoint.y);
}

ImVec2 world2screen_i(Vector3 pos) {
    auto cam = get_camera();
    if (!cam) return {0,0};

    Vector3 worldPoint = WTS(cam,pos);

    return {worldPoint.x,glHeight - worldPoint.y};
}

ImFont*weapon;
std::map<int, std::string> weaptofont = {
};


monoString*GetPlayerWeapon(void*a) {
    auto w1 = *(void **) ((uint64_t) a + 0x68);
    if (w1) {
        auto w2 = *(void **) ((uint64_t) w1 + 0x98);
        if (w2) {
            auto w3 = *(void **) ((uint64_t) w2 + 0xA0);
            if (w3) {
                auto w4 = *(monoString**) ((uint64_t) w3 + 0x20);
                if (w4) return w4;
            }
        }
    }
}
int get_weaponid(void*a) {
        auto w1 = *(void **) ((uint64_t) a + 0x68);
        if (w1) {
            auto w2 = *(void **) ((uint64_t) w1 + 0x98);
            if (w2) {
                auto w3 = *(void **) ((uint64_t) w2 + 0xA0);
                if (w3) {
                    auto w4 = *(int *) ((uint64_t) w3 + 0x18);
                    if (w4) return w4;
                }
            }
        }
    }

float X1, Y1, Z1;
float get_3D_Distance(float Self_x, float Self_y, float Self_z, float Object_x, float Object_y, float Object_z)
{
    float x, y, z;
    x = Self_x - Object_x;
    y = Self_y - Object_y;
    z = Self_z - Object_z;
    return (float)(sqrt(x * x + y * y + z * z));
}

inline void arc(float x, float y, float radius, float min_angle, float max_angle, ImColor col, float thickness) {
    ImGui::GetBackgroundDrawList()->PathArcTo(ImVec2 (x, y), radius, Deg2Rad * min_angle, Deg2Rad * max_angle, 32);
    ImGui::GetBackgroundDrawList()->PathStroke(col, false, thickness);
	}
	
	void DrawRectGlow(ImVec2 start, ImVec2 end, ImVec4 col,int gsize) {
    for (int i = 0; i < gsize; i++) {
        ImGui::GetBackgroundDrawList()->AddRectFilled(ImVec2(start.x - i, start.y - i), ImVec2(end.x + i, end.y + i), ImGui::GetColorU32(ImVec4(col.x, col.y, col.z, col.w * (1.0f / (float)gsize) * (((float)(gsize - i)) / (float)gsize))));
    }
    ImGui::GetBackgroundDrawList()->AddRectFilled(start, end, ImGui::GetColorU32(col));
}

void DrawRectGlow1(ImVec2 start, ImVec2 end, ImVec4 col, ImVec4 col1, int gsize) {
    for (int i = 0; i < gsize; i++) {
        ImGui::GetBackgroundDrawList()->AddRectFilledMultiColor(ImVec2(start.x - i, start.y - i), ImVec2(end.x + i, end.y + i), ImGui::GetColorU32(ImVec4(col.x, col.y, col.z, col.w * (1.0f / (float)gsize) * (((float)(gsize - i)) / (float)gsize))), ImGui::GetColorU32(ImVec4(col.x, col.y, col.z, col.w * (1.0f / (float)gsize) * (((float)(gsize - i)) / (float)gsize))), ImGui::GetColorU32(ImVec4(col1.x, col1.y, col1.z, col1.w * (1.0f / (float)gsize) * (((float)(gsize - i)) / (float)gsize))), ImGui::GetColorU32(ImVec4(col1.x, col1.y, col1.z, col1.w * (1.0f / (float)gsize) * (((float)(gsize - i)) / (float)gsize))));
    }
    ImGui::GetBackgroundDrawList()->AddRectFilledMultiColor(start, end, ImGui::GetColorU32(col), ImGui::GetColorU32(col), ImGui::GetColorU32(col1), ImGui::GetColorU32(col1));
}
void DrawRectGlow2(ImVec2 start, ImVec2 end, ImVec4 col, ImVec4 col1, int gsize) {
    for (int i = 0; i < gsize; i++) {
        ImGui::GetBackgroundDrawList()->AddRectFilledMultiColor(ImVec2(start.x - i, start.y - i), ImVec2(end.x + i, end.y + i), ImGui::GetColorU32(ImVec4(col1.x, col1.y, col1.z, col1.w * (1.0f / (float)gsize) * (((float)(gsize - i)) / (float)gsize))), ImGui::GetColorU32(ImVec4(col.x, col.y, col.z, col.w * (1.0f / (float)gsize) * (((float)(gsize - i)) / (float)gsize))), ImGui::GetColorU32(ImVec4(col.x, col.y, col.z, col.w * (1.0f / (float)gsize) * (((float)(gsize - i)) / (float)gsize))), ImGui::GetColorU32(ImVec4(col1.x, col1.y, col1.z, col1.w * (1.0f / (float)gsize) * (((float)(gsize - i)) / (float)gsize))));
    }
    ImGui::GetBackgroundDrawList()->AddRectFilledMultiColor(start, end, ImGui::GetColorU32(col1), ImGui::GetColorU32(col), ImGui::GetColorU32(col), ImGui::GetColorU32(col1));
}


void DrawEsp() 
	{
		if (esp::player::draw) {
		if (!GameManager$$Game()) return;
	il2cpp_field_static_get_value((FieldInfo*) lazySingletonField, &lazySingleton);
	if (lazySingleton != NULL) {
	} else {
		return;
	}
	playerc = *(void **) ((uint64_t) lazySingleton + string2Offset(OBFUSCATE("0x80")));
	if (playerc != NULL) {
	} else {
		return;
	}
	player = *(monoDictionary<int, void*> **)((uint64_t) lazySingleton + string2Offset(OBFUSCATE("0x28")));
	if (player != NULL) {
	} else {
		return;
	}
	int sizes = player->getSize();
	if (sizes < 1) {
		return;
	}
	static auto GetTeam = (int (*)(void *))(il2cpp_base + string2Offset(OBFUSCATE("0x2510048")));;
	auto players = player->getValues();
	if (players.empty()) return;
	
	for (int i = 0; i < player->getSize(); i++) {
		auto playerss = players[i];
		
	if (playerc != NULL && playerss != NULL) {
		if (GetTeam(get_photon(playerss)) != GetTeam(get_photon(playerc))) {
			void* camera = get_camera();
			Vector3 HeadPos= get_position(get_transform(playerss))+Vector3(0,1.9f,0);
  Vector3 HeadPos2= get_position(get_transform(playerss))+Vector3(0,0,0);
  Vector3 Toepos= get_position(get_transform(playerss));
  Vector3 Toeposi= WTS(camera, Vector3(Toepos.x,Toepos.y,Toepos.z));
  Vector3 HeadPosition = WTS(camera, Vector3(HeadPos.x,HeadPos.y,HeadPos.z));
  Vector3 HeadPosition2 = WTS(camera, Vector3(HeadPos2.x,HeadPos2.y,HeadPos2.z));
  Vector3 viewpos = get_position(get_transform(get_camera()));
  auto posit = get_position(get_transform(playerss));
  auto distance = Vector3::Distance(viewpos, posit);
  auto ray = visiblechecker[playerss];
  auto checker = false;
  auto pname = GetPlayerName(get_photon(playerss));
  auto money = GetPlayerMoney(get_photon(playerss));
  auto pos = get_position(get_transform(playerss));
  std::string names = "null";
  if (pname) names = pname->get_string();
  std::transform(names.begin(), names.end(), names.begin(), ::tolower);
  std::string name = names;
  auto playername = names;
  auto weap = GetPlayerWeapon(playerss);
  std::string weaps = "null";
  if (weap) weaps = weap->get_string();
  std::transform(weaps.begin(), weaps.end(), weaps.begin(), ::tolower);
  std::string wpn = weaps;
  int Hight = HeadPosition.y - Toeposi.y;
  int Width = Hight *0.6;
  auto w2sC = world2screen_c(posit + Vector3(0, 0.9, 0), checker);
  auto render = ImGui::GetBackgroundDrawList();
  Vector2 DrawTo = Vector2(HeadPosition.x, (glHeight - HeadPosition.y));
                Vector2 DrawTo1 = Vector2(HeadPosition2.x, (glHeight - HeadPosition2.y));
				if (HeadPosition.z >1.0f) {
					if(esp::player::fill) {
					render->AddRectFilled(ImVec2(HeadPosition.x - (Width/2),glHeight-HeadPosition.y),ImVec2(HeadPosition.x+(Width/2),glHeight-HeadPosition.y+Hight),ImColor(colors::esp::player::boxColor[0],colors::esp::player::boxColor[1],colors::esp::player::boxColor[2],colors::esp::player::fill_value/255));
					}
					if(esp::player::box){
				ImGui::GetBackgroundDrawList()->AddRect(ImVec2(HeadPosition.x-Width/2,glHeight-HeadPosition.y), ImVec2(HeadPosition.x+Width/2,glHeight-HeadPosition.y+Hight), ImGui::ColorConvertFloat4ToU32(ImVec4(0,0,0,1)),cornedbox,0,4);
				ImGui::GetBackgroundDrawList()->AddRect(ImVec2(HeadPosition.x-Width/2,glHeight-HeadPosition.y), ImVec2(HeadPosition.x+Width/2,glHeight-HeadPosition.y+Hight), ImGui::ColorConvertFloat4ToU32(ImVec4(BoxColor)),cornedbox,0,2);
                }
				if (esp::player::dist) {
                          Vector3 MyPosi222 = get_position(get_transform(get_camera()));
                          int DistanceTo = get_3D_Distance(MyPosi222.x, MyPosi222.y, MyPosi222.z,
                          HeadPos.x, HeadPos.y, HeadPos.z);
                          char extra[10];
						  auto textsize1 = 8; 
					//	  if(smallpixel){
                          sprintf(extra, " %0.0fm", DistanceTo);
		              	  DrawText((std::to_string(DistanceTo)+"m").c_str(), ImVec2(HeadPosition.x+18.6+Width/2,glHeight-HeadPosition.y+13), ImVec2(0, -1), ImColor(255, 255, 155), true, 12);
					  
					  }
					  if(esp::player::name){
			          DrawText(name.c_str(),ImVec2(HeadPosition.x-18/2,glHeight-HeadPosition.y- 5), ImVec2(0, -1), ImColor(255, 255, 255), true, 17);
				      }
					  if (esp::player::money){
    auto money = GetPlayerMoney(get_photon(playerss));
    std::string dist = (std::to_string((int) money) +          "$");
   ImGui::GetBackgroundDrawList()->AddText(ImGui::GetFont(),16.5f,ImVec2(HeadPosition.x+3+Width/2+1,glHeight-HeadPosition.y+19), ImGui::ColorConvertFloat4ToU32(ImVec4(0,0,0, 1)), dist.c_str());
   ImGui::GetBackgroundDrawList()->AddText(ImGui::GetFont(),16.5f,ImVec2(HeadPosition.x+3+Width/2-2,glHeight-HeadPosition.y+18), ImGui::ColorConvertFloat4ToU32(ImVec4(0,0,0, 1)), dist.c_str());
   ImGui::GetBackgroundDrawList()->AddText(ImGui::GetFont(),16.5f,ImVec2(HeadPosition.x+3+Width/2+2,glHeight-HeadPosition.y+22), ImGui::ColorConvertFloat4ToU32(ImVec4(0,0,0, 1)), dist.c_str());
   ImGui::GetBackgroundDrawList()->AddText(ImGui::GetFont(),16.5f,ImVec2(HeadPosition.x+3+Width/2-1,glHeight-HeadPosition.y+21), ImGui::ColorConvertFloat4ToU32(ImVec4(0,0,0, 1)), dist.c_str());
   ImGui::GetBackgroundDrawList()->AddText(ImGui::GetFont(),16.5f,ImVec2(HeadPosition.x+3+Width/2,glHeight-HeadPosition.y+20), ImGui::ColorConvertFloat4ToU32(ImVec4(MoneyColor)), dist.c_str());
   }
   if(esp::player::weapon){
												int wid = get_weaponid(playerss);
												std::string weapng = weaptofont[wid];	
												int h = GetArmor(get_photon(playerss));
												if(!esp::player::armor||h==0){
													ImGui::PushFont(SkeetSmall);
													render->AddText(ImVec2((HeadPosition.x-ImGui::CalcTextSize(wpn.c_str()).x/2)-1,(glHeight-HeadPosition2.y)+1), ImGui::ColorConvertFloat4ToU32(ImVec4(0, 0, 0, 1)), wpn.c_str());
													render->AddText(ImVec2((HeadPosition.x-ImGui::CalcTextSize(wpn.c_str()).x/2)-1,(glHeight-HeadPosition2.y)-1), ImGui::ColorConvertFloat4ToU32(ImVec4(0, 0, 0, 1)), wpn.c_str());
		   											render->AddText(ImVec2((HeadPosition.x-ImGui::CalcTextSize(wpn.c_str()).x/2)+1,(glHeight-HeadPosition2.y)+1), ImGui::ColorConvertFloat4ToU32(ImVec4(0, 0, 0, 1)), wpn.c_str());
		   											render->AddText(ImVec2((HeadPosition.x-ImGui::CalcTextSize(wpn.c_str()).x/2)+1,(glHeight-HeadPosition2.y)-1), ImGui::ColorConvertFloat4ToU32(ImVec4(0, 0, 0, 1)), wpn.c_str());
					    							render->AddText(ImVec2(HeadPosition.x-ImGui::CalcTextSize(wpn.c_str()).x/2,glHeight-HeadPosition2.y), ImGui::ColorConvertFloat4ToU32(ImVec4(1, 1, 1, 1)), wpn.c_str());
													ImGui::PopFont();
							
													ImGui::PushFont(weapon);
													render->AddText(ImVec2((HeadPosition.x-ImGui::CalcTextSize(weapng.c_str()).x/2),(glHeight-HeadPosition2.y+ImGui::CalcTextSize(weapng.c_str()).y/2)+1), ImGui::ColorConvertFloat4ToU32(ImVec4(0, 0, 0, 1)), weapng.c_str());
													render->AddText(ImVec2((HeadPosition.x-ImGui::CalcTextSize(weapng.c_str()).x/2)-1,(glHeight-HeadPosition2.y+ImGui::CalcTextSize(weapng.c_str()).y/2)-1), ImGui::ColorConvertFloat4ToU32(ImVec4(0, 0, 0, 1)), weapng.c_str());
		   											render->AddText(ImVec2((HeadPosition.x-ImGui::CalcTextSize(weapng.c_str()).x/2)+1,(glHeight-HeadPosition2.y+ImGui::CalcTextSize(weapng.c_str()).y/2)+1), ImGui::ColorConvertFloat4ToU32(ImVec4(0, 0, 0, 1)), weapng.c_str());
		   											render->AddText(ImVec2((HeadPosition.x-ImGui::CalcTextSize(weapng.c_str()).x/2)+1,(glHeight-HeadPosition2.y+ImGui::CalcTextSize(weapng.c_str()).y/2)-1), ImGui::ColorConvertFloat4ToU32(ImVec4(0, 0, 0, 1)), weapng.c_str());
					    							render->AddText(ImVec2(HeadPosition.x-ImGui::CalcTextSize(weapng.c_str()).x/2,glHeight-HeadPosition2.y+ImGui::CalcTextSize(weapng.c_str()).y/2), ImGui::ColorConvertFloat4ToU32(ImVec4(1, 1, 1, 1)), weapng.c_str());
													ImGui::PopFont();
							
												} else {
													ImGui::PushFont(SkeetSmall);
													render->AddText(ImVec2((HeadPosition.x-ImGui::CalcTextSize(wpn.c_str()).x/2)-1,(glHeight-HeadPosition2.y)+8), ImGui::ColorConvertFloat4ToU32(ImVec4(0, 0, 0, 1)), wpn.c_str());
													render->AddText(ImVec2((HeadPosition.x-ImGui::CalcTextSize(wpn.c_str()).x/2)-1,(glHeight-HeadPosition2.y)+10), ImGui::ColorConvertFloat4ToU32(ImVec4(0, 0, 0, 1)), wpn.c_str());
		   											render->AddText(ImVec2((HeadPosition.x-ImGui::CalcTextSize(wpn.c_str()).x/2)+1,(glHeight-HeadPosition2.y)+8), ImGui::ColorConvertFloat4ToU32(ImVec4(0, 0, 0, 1)), wpn.c_str());
		   											render->AddText(ImVec2((HeadPosition.x-ImGui::CalcTextSize(wpn.c_str()).x/2)+1,(glHeight-HeadPosition2.y)+10), ImGui::ColorConvertFloat4ToU32(ImVec4(0, 0, 0, 1)), wpn.c_str());
					    							render->AddText(ImVec2(HeadPosition.x-ImGui::CalcTextSize(wpn.c_str()).x/2,glHeight-HeadPosition2.y+9), ImGui::ColorConvertFloat4ToU32(ImVec4(1, 1, 1, 1)), wpn.c_str());
													ImGui::PopFont();
							
													ImGui::PushFont(weapon);
													render->AddText(ImVec2((HeadPosition.x-ImGui::CalcTextSize(weapng.c_str()).x/2)-1,(glHeight-HeadPosition2.y+9+ImGui::CalcTextSize(weapng.c_str()).y/2)+1), ImGui::ColorConvertFloat4ToU32(ImVec4(0, 0, 0, 1)), weapng.c_str());
													render->AddText(ImVec2((HeadPosition.x-ImGui::CalcTextSize(weapng.c_str()).x/2)-1,(glHeight-HeadPosition2.y+9+ImGui::CalcTextSize(weapng.c_str()).y/2)-1), ImGui::ColorConvertFloat4ToU32(ImVec4(0, 0, 0, 1)), weapng.c_str());
		   											render->AddText(ImVec2((HeadPosition.x-ImGui::CalcTextSize(weapng.c_str()).x/2)+1,(glHeight-HeadPosition2.y+9+ImGui::CalcTextSize(weapng.c_str()).y/2)+1), ImGui::ColorConvertFloat4ToU32(ImVec4(0, 0, 0, 1)), weapng.c_str());
		   											render->AddText(ImVec2((HeadPosition.x-ImGui::CalcTextSize(weapng.c_str()).x/2)+1,(glHeight-HeadPosition2.y+9+ImGui::CalcTextSize(weapng.c_str()).y/2)-1), ImGui::ColorConvertFloat4ToU32(ImVec4(0, 0, 0, 1)), weapng.c_str());
					    							render->AddText(ImVec2(HeadPosition.x-ImGui::CalcTextSize(weapng.c_str()).x/2,glHeight-HeadPosition2.y+9+ImGui::CalcTextSize(weapng.c_str()).y/2), ImGui::ColorConvertFloat4ToU32(ImVec4(1, 1, 1, 1)), weapng.c_str());
													ImGui::PopFont();
							
												}
											}
											if(esp::player::armor){
												int h = GetArmor(get_photon(playerss));
												if(h>0){
													if(esp::player::armortype==0){
														render->AddRectFilled(ImVec2(HeadPosition.x-1 - Width / 2, glHeight - HeadPosition2.y+3), ImVec2(HeadPosition.x+1 + Width / 2, glHeight - HeadPosition2.y+9), ImGui::ColorConvertFloat4ToU32(ImVec4(0,0,0, 1.0f)));
														DrawRectGlow(ImVec2(HeadPosition.x - Width / 2, glHeight - HeadPosition2.y + 4), ImVec2((HeadPosition.x - float(Width / 2) + float(Width * (h / 100.f))), glHeight - HeadPosition2.y + 8), ImVec4(colors::esp::player::armorColor[0],colors::esp::player::armorColor[1],colors::esp::player::armorColor[2],1), (int)esp::player::glow);
														if(h<100){
															ImGui::PushFont(SkeetSmall);
				   											render->AddText(ImVec2((HeadPosition.x -11- float(Width / 2) + float(Width * (h / 100.f)))-1,(glHeight - HeadPosition2.y + 7-ImGui::CalcTextSize(std::to_string(h).c_str()).y/2)+1), ImGui::ColorConvertFloat4ToU32(ImVec4(0,0,0, 1)), std::to_string(h).c_str());
															render->AddText(ImVec2((HeadPosition.x-11 - float(Width / 2) + float(Width * (h / 100.f)))-1,(glHeight - HeadPosition2.y + 7-ImGui::CalcTextSize(std::to_string(h).c_str()).y/2)-1), ImGui::ColorConvertFloat4ToU32(ImVec4(0,0,0, 1)), std::to_string(h).c_str());
															render->AddText(ImVec2((HeadPosition.x-11 - float(Width / 2) + float(Width * (h / 100.f)))+1,(glHeight - HeadPosition2.y + 7-ImGui::CalcTextSize(std::to_string(h).c_str()).y/2)+1), ImGui::ColorConvertFloat4ToU32(ImVec4(0,0,0, 1)), std::to_string(h).c_str());
															render->AddText(ImVec2((HeadPosition.x-11 - float(Width / 2) + float(Width * (h / 100.f)))+1,(glHeight - HeadPosition2.y + 7-ImGui::CalcTextSize(std::to_string(h).c_str()).y/2)-1), ImGui::ColorConvertFloat4ToU32(ImVec4(0,0,0, 1)),std::to_string(h).c_str());
															render->AddText(ImVec2((HeadPosition.x -11- float(Width / 2) + float(Width * (h / 100.f))),glHeight - HeadPosition2.y + 7-ImGui::CalcTextSize(std::to_string(h).c_str()).y/2), ImGui::ColorConvertFloat4ToU32(ImVec4(1,1,1, 1)), std::to_string(h).c_str());
															ImGui::PopFont();
														}
													}
													if(esp::player::armortype == 1){
														render->AddRectFilled(ImVec2(HeadPosition.x-1 - Width / 2, glHeight - HeadPosition2.y+3), ImVec2(HeadPosition.x+1 + Width / 2, glHeight - HeadPosition2.y+9), ImGui::ColorConvertFloat4ToU32(ImVec4(0,0,0, 1.0f)));
        												DrawRectGlow2(ImVec2(HeadPosition.x - Width / 2, glHeight - HeadPosition2.y + 4), ImVec2((HeadPosition.x - float(Width / 2) + float(Width * (h / 100.f))), glHeight - HeadPosition2.y + 8),  ImVec4(armorcolor1[0], armorcolor1[1], armorcolor1[2], 1.0f), ImVec4(armorcolor2[0], armorcolor2[1], armorcolor2[2], 1.0f),(int)esp::player::glow);
														if(h<100){
															ImGui::PushFont(SkeetSmall);
				   											render->AddText(ImVec2((HeadPosition.x -11- float(Width / 2) + float(Width * (h / 100.f)))-1,(glHeight - HeadPosition2.y + 6-ImGui::CalcTextSize(std::to_string(h).c_str()).y/2)+1), ImGui::ColorConvertFloat4ToU32(ImVec4(0,0,0, 1)), std::to_string(h).c_str());
															render->AddText(ImVec2((HeadPosition.x -11- float(Width / 2) + float(Width * (h / 100.f)))-1,(glHeight - HeadPosition2.y + 6-ImGui::CalcTextSize(std::to_string(h).c_str()).y/2)-1), ImGui::ColorConvertFloat4ToU32(ImVec4(0,0,0, 1)), std::to_string(h).c_str());
															render->AddText(ImVec2((HeadPosition.x -11- float(Width / 2) + float(Width * (h / 100.f)))+1,(glHeight - HeadPosition2.y + 6-ImGui::CalcTextSize(std::to_string(h).c_str()).y/2)+1), ImGui::ColorConvertFloat4ToU32(ImVec4(0,0,0, 1)), std::to_string(h).c_str());
															render->AddText(ImVec2((HeadPosition.x -11- float(Width / 2) + float(Width * (h / 100.f)))+1,(glHeight - HeadPosition2.y + 6-ImGui::CalcTextSize(std::to_string(h).c_str()).y/2)-1), ImGui::ColorConvertFloat4ToU32(ImVec4(0,0,0, 1)),std::to_string(h).c_str());
															render->AddText(ImVec2((HeadPosition.x -11- float(Width / 2) + float(Width * (h / 100.f))),glHeight - HeadPosition2.y + 6-ImGui::CalcTextSize(std::to_string(h).c_str()).y/2), ImGui::ColorConvertFloat4ToU32(ImVec4(1,1,1, 1)), std::to_string(h).c_str());
															ImGui::PopFont();
														}
													}
												}
											}
if (esp::player::line){
     		if (esp::player::linetype == 1){
			Alacrium::DrawLineGlowW(ImVec2(glWidth/2,glHeight), ImVec2(HeadPosition2.x,glHeight- HeadPosition2.y), ImGui::ColorConvertFloat4ToU32(ImVec4(BoxColor)), 1, 10);
            ImGui::GetBackgroundDrawList()->AddLine(ImVec2(glWidth/2,glHeight), ImVec2(HeadPosition2.x,glHeight- HeadPosition2.y), ImGui::ColorConvertFloat4ToU32(ImVec4(LineColor)), 0.5);
			}
			if(esp::player::linetype == 0){
			Alacrium::DrawLineGlowW(ImVec2(glWidth/2,0), ImVec2(HeadPosition.x,glHeight- HeadPosition.y), ImGui::ColorConvertFloat4ToU32(ImVec4(BoxColor)), 1, 10);
			ImGui::GetBackgroundDrawList()->AddLine(ImVec2(glWidth/2,0), ImVec2(HeadPosition.x,glHeight- HeadPosition.y), ImGui::ColorConvertFloat4ToU32(ImVec4(LineColor)), 0.5);
			}
			}

 
											if(esp::player::health){
						
												float health = GetHealth(get_photon(playerss));
                    							int h = ((int) health);
                    							int x = DrawTo.x - Width/2 - 10;
                   								int y = DrawTo.y;
                    							auto Render = render;
												if(esp::player::healthtype==0) {
													Render->AddRectFilled(ImVec2(x, y - 1),ImVec2(x + 6, y + 1 + Hight),ImColor(0, 0, 0, 200));
													DrawRectGlow(ImVec2(x + 1,y +Hight -(Hight *(health /100))),ImVec2(x + 5,y +Hight),ImVec4(colors::esp::player::HpColor[0],colors::esp::player::HpColor[1],colors::esp::player::HpColor[2],1),(int)esp::player::glow);
												}
												if(esp::player::healthtype==1) {
													Render->AddRectFilled(ImVec2(x, y - 1),ImVec2(x + 6, y + 1 + Hight),ImColor(0, 0, 0, 200));
													DrawRectGlow1(ImVec2(x + 1,y +Hight -(Hight *(health/100))),ImVec2(x + 5,y +Hight), ImVec4(hpcolor1[0], hpcolor1[1], hpcolor1[2], 1.0f), ImVec4(hpcolor2[0], hpcolor2[1], hpcolor2[2], 1.0f),(int)esp::player::glow);
												}
												if(h <100){
													ImGui::PushFont(SkeetSmall);
				   									render->AddText(ImVec2((x+3)-ImGui::CalcTextSize(std::to_string(h).c_str()).x/2,y-9 +Hight -(Hight *(health /100))), ImGui::ColorConvertFloat4ToU32(ImVec4(0,0,0, 1)), std::to_string(h).c_str());		  
													render->AddText(ImVec2((x+3)-ImGui::CalcTextSize(std::to_string(h).c_str()).x/2,y -7+Hight -(Hight *(health /100))), ImGui::ColorConvertFloat4ToU32(ImVec4(0,0,0, 1)), std::to_string(h).c_str());		  
													render->AddText(ImVec2((x+5)-ImGui::CalcTextSize(std::to_string(h).c_str()).x/2,y-9 +Hight -(Hight *(health /100))), ImGui::ColorConvertFloat4ToU32(ImVec4(0,0,0, 1)), std::to_string(h).c_str());		  
													render->AddText(ImVec2((x+5)-ImGui::CalcTextSize(std::to_string(h).c_str()).x/2,y -7+Hight -(Hight *(health /100))), ImGui::ColorConvertFloat4ToU32(ImVec4(0,0,0, 1)), std::to_string(h).c_str());		
													render->AddText(ImVec2((x+4)-ImGui::CalcTextSize(std::to_string(h).c_str()).x/2,y-8+Hight -(Hight *(health /100))), ImGui::ColorConvertFloat4ToU32(ImVec4(1,1,1, 1)), std::to_string(h).c_str());
													ImGui::PopFont();
												}
											}
															}
															}
															}
					
                            }
                        }
					}


class MyModule : public zygisk::ModuleBase {
 public:
  void onLoad(Api *api, JNIEnv *env) override {
    this->api_ = api;
    this->env_ = env;
  }

  void preAppSpecialize(AppSpecializeArgs *args) override {
    static constexpr const char *packages[] = {
        "com.axlebolt.standoff2"
    };
    const char *process = env_->GetStringUTFChars(args->nice_name, nullptr);
    for (const auto *package: packages) {
      is_game_ = (strcmp(process, package) == 0);
      if (is_game_) {
        break;
      }
    }
    env_->ReleaseStringUTFChars(args->nice_name, process);
  }

  void postAppSpecialize(const AppSpecializeArgs *args) override {
    if (is_game_) {
      std::thread{hack}.detach();
    }
  }

 private:
  Api *api_ = nullptr;
  JNIEnv *env_ = nullptr;
  bool is_game_ = false;
};


bool poloska = true;
bool menuopened;
#define HOOKAF(ret, func, ...) \
    ret (*orig##func)(__VA_ARGS__); \
    ret my##func(__VA_ARGS__)
HOOKAF(void, Input, void *thiz, void *ex_ab, void *ex_ac) {
    origInput(thiz, ex_ab, ex_ac);
    ImGui_ImplAndroid_HandleInputEvent((AInputEvent *)thiz);
    return;
}
void SetupImgui() {
    // Setup Dear ImGui context
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
	io.DisplaySize = ImVec2((float)glWidth, (float)glHeight);
   // ImGui::StyleColorsLight();
    ImGui_ImplOpenGL3_Init("#version 100");
    ImGui::GetStyle().ScaleAllSizes(5.0f);

    // We load the default font with increased size to improve readability on many devices with "high" DPI.
    ImFontConfig font_cfg;
    font_cfg.SizePixels = 28.0f;
    font_cfg.GlyphRanges = io.Fonts->GetGlyphRangesCyrillic();
    io.Fonts->AddFontFromMemoryTTF(&Verdana, sizeof Verdana, 30.0f, &font_cfg);
   
    io.FontGlobalScale = 1.0f;
}
void TextCentered(std::string text) {
    auto windowWidth = ImGui::GetWindowSize().x;
    auto textWidth   = ImGui::CalcTextSize(text.c_str()).x;
    ImGui::SetCursorPosX((windowWidth - textWidth) * 0.5f);
    ImGui::Text(text.c_str());
}

void DrawMenu() {

    if (poloska) {
   float dpiscale = 1.50f;
   ImGui::PushStyleColor(ImGuiCol_WindowBg, ImColor(0, 0, 0, 0).Value);
   ImGui::PushStyleColor(ImGuiCol_Border, ImColor(0, 0, 0, 0).Value);
   ImGui::GetStyle().WindowMinSize = ImVec2(0, 0);
   ImGui::SetNextWindowPos(
   ImVec2(glWidth / 2 - 100.0f * dpiscale, glHeight - 60.0f * dpiscale));
   ImGui::SetNextWindowSize(ImVec2(380.000f, 500.0f), ImGuiCond_Once);
   ImGui::Begin(OBFUSCATE("#open"), &poloska,
   ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoTitleBar |
   ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoResize);
   if (ImGui::InvisibleButton(OBFUSCATE("##plthook"), ImGui::GetWindowSize()))
   
    menuopened = !menuopened;;
    
    ImGui::GetWindowDrawList()->AddRectFilled(
    ImVec2(glWidth / 2 - 100.0f * dpiscale, glHeight - 15.0f * dpiscale),
    ImVec2(glWidth / 2 + 100.0f * dpiscale, glHeight - 10.0f * dpiscale),
    ImColor(255, 255, 255), 10.0f * dpiscale);ImGui::PopStyleColor(2);             
   } 
      
   if (menuopened) {
    ImGui::SetNextWindowSize(ImVec2(900,522),ImGuiCond_FirstUseEver);
    ImGui::Begin(OBFUSCATE("Meteor Project"));
	
	if(ImGui::CollapsingHeader(OBFUSCATE("ESP"))){
		ImGui::Checkbox(OBFUSCATE("Enable"), &esp::player::draw);
	if (esp::player::draw) {
		ImGui::Checkbox(OBFUSCATE("Box"),&esp::player::box);
		ImGui::Checkbox(OBFUSCATE("Fill"),&esp::player::fill);
		ImGui::Checkbox(OBFUSCATE("Tracer"),&esp::player::line);
		if(esp::player::line){
	    ImGui::Combo(OBFUSCATE("Type Line"), &esp::player::linetype, TypesLine,IM_ARRAYSIZE(TypesLine));
		}
		ImGui::Checkbox(OBFUSCATE("Health"),&esp::player::health);
		ImGui::Checkbox(OBFUSCATE("Money"),&esp::player::money);
		ImGui::Checkbox(OBFUSCATE("Distance"),&esp::player::dist);
		ImGui::Checkbox(OBFUSCATE("Nickname"),&esp::player::name);
		ImGui::Checkbox(OBFUSCATE("Armor"),&esp::player::armor);
		ImGui::Checkbox(OBFUSCATE("Weapon"),&esp::player::weapon);
    	ImGui::Combo(OBFUSCATE("Health Type"), &esp::player::healthtype, esp::player::hptype, IM_ARRAYSIZE(esp::player::hptype));
		switch (esp::player::healthtype){
			case 0:
				ImGui::ColorEdit3(OBFUSCATE("Health Color"),colors::esp::player::HpColor,ImGuiColorEditFlags_NoInputs);
			break;
			case 1:
				ImGui::ColorEdit3(OBFUSCATE("Hp Color1"), hpcolor1,ImGuiColorEditFlags_NoInputs);
				ImGui::ColorEdit3(OBFUSCATE("Hp Color2"), hpcolor2,ImGuiColorEditFlags_NoInputs);
			break;
		}
		ImGui::Combo(OBFUSCATE("Armor Type"), &esp::player::armortype, esp::player::armortypes, IM_ARRAYSIZE(esp::player::armortypes));
		switch (esp::player::armortype){
			case 0:
				ImGui::ColorEdit3(OBFUSCATE("Armor Color"),colors::esp::player::armorColor,ImGuiColorEditFlags_NoInputs);
			break;
			case 1:
				ImGui::ColorEdit3(OBFUSCATE("Armor Color1"), armorcolor2,ImGuiColorEditFlags_NoInputs);
				ImGui::ColorEdit3(OBFUSCATE("Armot Color2"), armorcolor1,ImGuiColorEditFlags_NoInputs);
			break;
		}
    	ImGui::SliderFloat(OBFUSCATE("Glow Size"),&esp::player::glow,0,30);
		ImGui::SliderFloat(OBFUSCATE("Fill Value"),&colors::esp::player::fill_value,0,255);
		}
			}
			}
		if(ImGui::CollapsingHeader(OBFUSCATE("AIM"))){
			}
		if(ImGui::CollapsingHeader(OBFUSCATE("RAGE"))){
			ImGui::Checkbox(OBFUSCATE("Viewmodel X, Y, Z"), &viewmodel);
		   if (viewmodel) {
			   ImGui::SliderFloat(OBFUSCATE("X"), &X, -100, 100);
			   ImGui::SliderFloat(OBFUSCATE("Y"), &Y, -100, 100);
			   ImGui::SliderFloat(OBFUSCATE("Z"), &Z, -100, 100);
			}
			}
		if(ImGui::CollapsingHeader(OBFUSCATE("SKINS"))){
	ImGui::Combo(OBFUSCATE("Select Knife/Skin"), &knrn, kn, IM_ARRAYSIZE(kn));
	ImGui::Combo(OBFUSCATE("Select Gloves"), &glvn, gl, IM_ARRAYSIZE(gl));
	if (ImGui::Button(OBFUSCATE("Set Skin"))) {
		if (knrn == 0) {
			ChangeSkin(71005);
		}
		if (knrn == 1) {
			ChangeSkin(71003);
		}
		if (knrn == 2) {
			ChangeSkin(71004);
		}
		if (knrn == 3) {
			ChangeSkin(71001);
		}
		if (knrn == 4) {
			ChangeSkin(200012);
		}
		if (knrn == 5) {
			ChangeSkin(157100);
		}
		if (knrn == 6) {
			ChangeSkin(97100);
		}
		if (knrn == 7) {
			ChangeSkin(71002);
		}
		if (knrn == 8) {
			ChangeSkin(47504);
		}
		if (knrn == 9) {
			ChangeSkin(240068);
		}
		if (knrn == 10) {
			ChangeSkin(240111);
		}
		if (knrn == 11) {
			ChangeSkin(240113);
		}
		if (knrn == 12) {
			ChangeSkin(240112);
		}
		if (knrn == 13) {
			ChangeSkin(240109);
		}
		if (glvn == 1) {
			ChangeSkin(3027);
		}
		if (glvn == 2) {
		ChangeSkin(3026);
		}
		}
			}
    }		

EGLBoolean (*old_eglSwapBuffers)(EGLDisplay dpy, EGLSurface surface);
EGLBoolean hook_eglSwapBuffers(EGLDisplay dpy, EGLSurface surface) {
    eglQuerySurface(dpy, surface, EGL_WIDTH, &glWidth);
    eglQuerySurface(dpy, surface, EGL_HEIGHT, &glHeight);
   
    if (!setup) {
        SetupImgui();
        setup = true;
    }
    ImGui_ImplOpenGL3_NewFrame();
    ImGui::NewFrame();
    DrawMenu();
	DrawEsp();
	views();
    ImGui::End();
	        
    ImGui::EndFrame();
    ImGui::Render();
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());


    return old_eglSwapBuffers(dpy, surface);
}

void initOffsets() {
il2cpp_class_from_name = (void *(*)(void *, const char *, const char *))(il2cpp_base + string2Offset(OBFUSCATE("0x1F9B384")));
il2cpp_assembly_get_image = (void *(*)(void *))(il2cpp_base + string2Offset(OBFUSCATE("0x1FC22D0")));
il2cpp_class_get_field_from_name = (void *(*)(void *, const char *))(il2cpp_base + string2Offset(OBFUSCATE("0x1FC2384")));
il2cpp_domain_get = (void *(*)())(il2cpp_base + string2Offset(OBFUSCATE("0x1FC2484")));
il2cpp_domain_assembly_open = (void *(*)(void *, const char *))(il2cpp_base + string2Offset(OBFUSCATE("0x1FC2488")));
il2cpp_field_static_get_value = (void *(*)(void *, void *))(il2cpp_base + string2Offset(OBFUSCATE("0x1F8BAB4")));

MainController_Instance = (void *(*)())(il2cpp_base + string2Offset(OBFUSCATE("0x256475C")));
GameManager$$Game = (bool (*)())(il2cpp_base + string2Offset(OBFUSCATE("0x25E0BF8"))); 
get_transform = (void *(*)(void *))(il2cpp_base + string2Offset(OBFUSCATE("0x46508FC")));
get_position = (Vector3 (*)(void *))(il2cpp_base + string2Offset(OBFUSCATE("0x465CAD4")));
WTS = (Vector3 (*)(void *, Vector3))(il2cpp_base + string2Offset(OBFUSCATE("0x46236A0")));
get_bipedmap = (void *(*)(void *))(il2cpp_base + string2Offset(OBFUSCATE("0x2271330")));
get_camera = (void *(*)())(il2cpp_base + string2Offset(OBFUSCATE("0x4623A1C")));
GetHealth = (int (*)(void *))(il2cpp_base + string2Offset(OBFUSCATE("0x25C15D4")));
GetPlayerMoney = (int (*)(void*))(il2cpp_base + string2Offset(OBFUSCATE("0x21143B0")));
GetPlayerName = (monoString*(*)(void*))(il2cpp_base + string2Offset(OBFUSCATE("0x24FAA84")));
GetArmor = (int(*)(void*))(il2cpp_base + string2Offset(OBFUSCATE("0x25C0DA4")));

lazySingletonField = il2cpp_class_get_field_from_name((Il2CppClass *) il2cpp_class_from_name(((Il2CppAssembly*)il2cpp_domain_assembly_open(il2cpp_domain_get(),"Assembly-CSharp"))->image, OBFUSCATE("Axlebolt.Standoff.Main.Inventory"), OBFUSCATE("InventoryManager")), OBFUSCATE("GGEFFDEDGAAHBFE"));
lazySingletonField = il2cpp_class_get_field_from_name((Il2CppClass *) il2cpp_class_from_name(((Il2CppAssembly*)il2cpp_domain_assembly_open(il2cpp_domain_get(),"Assembly-CSharp"))->image, OBFUSCATE("Axlebolt.Standoff.Player"), OBFUSCATE("PlayerManager")), OBFUSCATE("GGEFFDEDGAAHBFE"));

}

void *cheat() {
system(OBFUSCATE("echo 0 > /proc/sys/kernel/randomize_va_space"));
il2cpp_base = getLib(OBFUSCATE("lib/arm64/libil2cpp.so"), OBFUSCATE("r--p"));
while (!il2cpp_base)
{
	sleep(1);
	il2cpp_base = getLib(OBFUSCATE("lib/arm64/libil2cpp.so"), OBFUSCATE("r--p"));
}
initOffsets();
//pthread_t t;
//pthread_create(&t, 0, maps_thread, 0);
//pthread_exit(nullptr);    
return NULL;}



//__attribute__((constructor))
void hack() {
cheat();
xhook_register(OBFUSCATE(".*\\.so$"), OBFUSCATE("_ZN7android13InputConsumer21initializeMotionEventEPNS_11MotionEventEPKNS_12InputMessageE"), (void *) myInput, (void **) &origInput);
xhook_register(OBFUSCATE(".*\\.so$"), OBFUSCATE("eglSwapBuffers"), (void*)hook_eglSwapBuffers, (void**)&old_eglSwapBuffers);
xhook_refresh(0);
}

REGISTER_ZYGISK_MODULE(MyModule)

